<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\UserRequest;
use App\Http\Requests\RegisterRequest;
use App\User;

class UserController extends Controller
{
    public function getLogin(){
        if(!Auth::check()){
            return view("User.login");
        }else{
            return redirect()->route('admin');
        }
    }
    
    public function postLogin(UserRequest $request){
        $login = array(
                'username' => $request->username,
                'password' => $request->password,
        );
        if (Auth::attempt($login)) {
            
        }else{
            return redirect()->back();
        }
        return redirect()->route('admin');
    }
    
    public function getLogout(){
        Auth::logout();
        return redirect()->route('getLogin');
    }
    
    public function getRegister(){
        return view('User.register');
    }
    
    public function postRegister(RegisterRequest $request){
        $data_input = $request->all();        
        if ($request->file('avatar')->isValid()) {
            $file = $request->file('avatar');
            $file_name = $data_input['username'].'.jpg';
            $data_input['avatar'] = 'uploads/'.$file_name;
            $file->move('uploads',$file_name);
        }
        User::create($data_input);
        return redirect()->route('admin');
    }
}
