Chào bạn,
<br>
Xin hãy click vào link sau để khôi phục mật khẩu của bạn
{{ url('password/reset/'.$token) }}
<br>
Thân,