<?php $__env->startSection('content'); ?>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('home'); ?>" data-toggle="modal">
            <i class="fa fa-home"></i>
            <p><?php echo e(trans('money_lover.wallet_home')); ?></p>
        </a>
    </div>

    <div class="menu-item green">
        <a href="<?php echo url('wallet'); ?>" data-toggle="modal">
            <i class="fa fa fa-money"></i>
            <p><?php echo e(trans('money_lover.wallet_all')); ?></p>
        </a>
    </div>

</div>

<div class="col-md-9 bg-white col-md-offset-0 padding-top-bot">
    <div class="col-md-8 col-md-offset-2">
        <h1 class="text-center"><?php echo e(trans('money_lover.wallet_new')); ?></h1>
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <ul>
                <li><?php echo session('message'); ?></li>
            </ul>
        </div>
        <?php endif; ?>
        <?php echo Form::open(array('url' => 'addwallet', 'files' => true, 'class'=>'form-signin padding-top-bot')); ?>

        <div class="form-group">
            <?php echo Form::label('name',Lang::get('money_lover.wallet_name').':'); ?>

            <?php echo Form::text('name',null, array('class'=>'form-control','placeholder'=>Lang::get('money_lover.wallet_name'))); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('money',Lang::get('money_lover.wallet_money').':'); ?>

            <?php echo Form::text('money',null, array('class'=>'form-control','placeholder'=>Lang::get('money_lover.wallet_money'))); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('type_money',Lang::get('money_lover.wallet_type').':'); ?>

            <?php echo Form::select('type_money', [''=>'--- '.Lang::get('money_lover.select').' ---','đ'=>'đ','$'=>'$','£'=>'£'], null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('note',Lang::get('money_lover.wallet_note').':'); ?>

            <?php echo Form::textarea('note', null, ['class' => 'form-control','placeholder'=>Lang::get('money_lover.wallet_note')."..."]); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('image',Lang::get('money_lover.wallet_avatar').':'); ?>

            <?php echo Form::file('image',['class'=>"btn btn-default btn-file form-control"]); ?>

            <p class="help-block"><?php echo e(trans('money_lover.wallet_avatar1')); ?></p>
        </div>
        <?php echo Form::submit(Lang::get('money_lover.wallet_new'),['class' => 'btn btn-success']); ?>

        <?php echo Form::close(); ?><!-- /form -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>