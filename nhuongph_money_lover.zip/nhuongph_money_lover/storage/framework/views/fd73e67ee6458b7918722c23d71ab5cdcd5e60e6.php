<?php $__env->startSection('content'); ?>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('home'); ?>" data-toggle="modal">
            <i class="fa fa-home"></i>
            <p><?php echo e(trans('money_lover.home')); ?></p>
        </a>
    </div>

    <div class="menu-item light-orange responsive-2">
        <a href="<?php echo url('addcategory'); ?>" data-toggle="modal">
            <i class="fa fa-plus"></i>
            <p><?php echo e(trans('money_lover.cate_new')); ?></p>
        </a>
    </div>

</div>

<div class="col-md-9 bg-white padding-top-bot col-md-offset-0">
    <div class="col-md-12 col-md-offset-0">
        <h1 class="text-center"><?php echo e(trans('money_lover.cate_all')); ?></h1>
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <ul>
                <li><?php echo session('message'); ?></li>
            </ul>
        </div>
        <?php endif; ?>
        <div class="wallet padding-top-bot">
            <table class="table table-striped" id="table_search">
                <tr>
                    <th>#</th>
                    <th><?php echo e(trans('money_lover.avatar')); ?></th>
                    <th><?php echo e(trans('money_lover.cate_name')); ?></th>
                    <th><?php echo e(trans('money_lover.note')); ?></th>
                    <th><?php echo e(trans('money_lover.action')); ?></th>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input class="form-control" type="text" id="search_name" name="search_name" placeholder="Search Name"/></td>
                    <td><input class="form-control" type="text" id="search_note" name="search_note" placeholder="Search Note"/></td>
                    <td></td>
                </tr>
                <?php foreach($categories as $key=>$var): ?>
                <tr class="foreach">
                    <td><?php echo e(($key+1)); ?></td>
                    <td><img src="<?php echo $var->image; ?>" /></td>
                    <td><?php echo $var->name; ?></td>
                    <td><?php echo $var->note; ?></td>
                    <td>
                        <a href="<?php echo url('updatecategory'); ?>/<?php echo $var->id; ?>">
                            <span class="glyphicon glyphicon-edit" aria-hidden="true" title="Edit infor Category"></span>
                        </a>&nbsp;
                        <a href="<?php echo url('deletecategory'); ?>/<?php echo $var->id; ?>" title="Delete Category">
                            <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                        </a>
                    </td>
                </tr>                
                <?php endforeach; ?>
            </table>  
            <div class="page"><?php echo $categories->links(); ?></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>