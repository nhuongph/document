Chào bạn,
<br>
Xin hãy click vào link sau để khôi phục mật khẩu của bạn
<?php echo e(url('password/reset/'.$token)); ?>

<br>
Thân,