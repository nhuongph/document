Chào bạn,
<br>
Xin hãy click vào link sau để hoàn thành quá trình đăng ký tài khoản của ban
<?php echo e(url('createAccount/'.$token)); ?>

<br>
Thân,