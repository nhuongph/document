<?php $__env->startSection('content'); ?>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('home'); ?>" data-toggle="modal">
            <i class="fa fa-home"></i>
            <p><?php echo e(trans('money_lover.home')); ?></p>
        </a>
    </div>

    <div class="menu-item light-red">
        <a href="<?php echo url('transactions'); ?>" data-toggle="modal">
            <i class="fa fa-shopping-cart"></i>
            <p><?php echo e(trans('money_lover.trans_all')); ?></p>
        </a>
    </div>

    <div class="menu-item color">
        <a href="<?php echo url('addtransaction'); ?>" data-toggle="modal">
            <i class="fa fa-pencil-square-o"></i>
            <p><?php echo e(trans('money_lover.trans_new')); ?></p>
        </a>
    </div>

    <div class="menu-item blue">
        <a href="<?php echo url('reportmonth'); ?>" data-toggle="modal">
            <i class="fa fa-area-chart"></i>
            <p><?php echo e(trans('money_lover.trans_report')); ?></p>
        </a>
    </div>

</div>

<div class="col-md-9 bg-white padding-top-bot col-md-offset-0">
    <h1 class="text-center"><?php echo e(trans('money_lover.trans_update')); ?></h1>
    <div class="col-md-10 col-md-offset-1 padding-top-bot">
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <ul>
                <li><?php echo session('message'); ?></li>
            </ul>
        </div>
        <?php endif; ?>
        <?php echo Form::open(array('url' => '/updatetransaction','class'=>'form-signin')); ?>

        <?php echo Form::hidden('id', $transaction->id); ?>

        <div class="form-group">
            <?php echo Form::label('category_id',Lang::get('money_lover.cate_name').':'); ?>

            <?php echo Form::select('category_id', $categories, $transaction->category_id, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('wallet_id',Lang::get('money_lover.wallet_name').':'); ?>

            <?php echo Form::select('wallet_id', $wallets, $transaction->wallet_id, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('money',Lang::get('money_lover.trans_money').':'); ?>

            <?php echo Form::text('money',$transaction->money, array('class'=>'form-control','placeholder'=>Lang::get('money_lover.trans_note'))); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('note',Lang::get('money_lover.note').':'); ?>

            <?php echo Form::textarea('note',$transaction->note, array('class'=>'form-control','placeholder'=>Lang::get('money_lover.note').'...')); ?>

        </div>
        <?php echo Form::submit(Lang::get('money_lover.trans_update'),['class' => 'btn btn-success']); ?>

        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>