<?php $__env->startSection('content'); ?>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('home'); ?>" data-toggle="modal">
            <i class="fa fa-home"></i>
            <p><?php echo e(trans('money_lover.wallet_home')); ?></p>
        </a>
    </div>

    <div class="menu-item green">
        <a href="<?php echo url('wallet'); ?>" data-toggle="modal">
            <i class="fa fa fa-money"></i>
            <p><?php echo e(trans('money_lover.wallet_all')); ?></p>
        </a>
    </div>

    <div class="menu-item blue">
        <a href="<?php echo url('addwallet'); ?>" data-toggle="modal">
            <i class="glyphicon glyphicon-star-empty"></i>
            <p><?php echo e(trans('money_lover.wallet_new')); ?></p>
        </a>
    </div>

</div>

<div class="col-md-9 bg-white padding-top-bot col-md-offset-0">

    <h1 class="text-center"><?php echo e(trans('money_lover.wallet_trans')); ?></h1>
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php foreach($errors->all() as $error): ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo session('message'); ?></li>
        </ul>
    </div>
    <?php endif; ?>
    <div class="wallet col-md-12">
        <h3><?php echo e(trans('money_lover.wallet_from')); ?></h3>
        <table class="table table-striped text-left padding-top-bot">
            <tr>
                <th><?php echo e(trans('money_lover.wallet_avatar2')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_name')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_money')); ?>(<?php echo $wallet->type_money; ?>)</th>
                <th><?php echo e(trans('money_lover.wallet_note')); ?></th>
            </tr>
            <tr>
                <td><img src="<?php echo asset($wallet->image); ?>" /></td>
                <td><?php echo $wallet->name; ?></td>
                <td><?php echo $wallet->money; ?></td>
                <td><?php echo $wallet->note; ?></td>                                    
            </tr>
        </table>
    </div>
    <div class="chose_wallet"> 
        <table class="table table-hover">
            <hr>
            <div class="col-md-8 col-md-offset-0">
                <h3><?php echo e(trans('money_lover.wallet_to')); ?></h3>
                <?php echo Form::open(array('url' => 'transwallet','class'=>'form-signin')); ?>

                <?php echo Form::hidden('id', $wallet->id); ?>

                <div class="form-group">
                    <?php echo Form::label('select_wallet',Lang::get('money_lover.wallet_to_1').':'); ?>

                    <?php echo Form::select('select_wallet', $wallets, null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label('trans_money',Lang::get('money_lover.wallet_to_2').':'); ?>

                    <?php echo Form::text('trans_money',null, array('class'=>'form-control','placeholder'=>Lang::get('money_lover.wallet_to_2'))); ?>

                </div>
                <?php echo Form::submit('Transfer Money',['class' => 'btn btn-success']); ?>


            </div>
        </table>
    </div>
    <?php echo Form::close(); ?><!-- /form -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>