<?php $__env->startSection('content'); ?>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('update'); ?>/<?php echo Auth::user()->username; ?>" data-toggle="modal">
            <i class="fa fa-user"></i>
            <p><?php echo e(trans('money_lover.user_update')); ?></p>
        </a>
    </div>

    <div class="menu-item green">
        <a href="<?php echo url('wallet'); ?>" data-toggle="modal">
            <i class="fa fa fa-money"></i>
            <p><?php echo e(trans('money_lover.wallet_all')); ?></p>
        </a>
    </div>

    <div class="menu-item blue">
        <a href="<?php echo url('addwallet'); ?>" data-toggle="modal">
            <i class="glyphicon glyphicon-star-empty"></i>
            <p><?php echo e(trans('money_lover.wallet_new')); ?></p>
        </a>
    </div>

</div>

<div class="col-md-6 text-center">

    <!-- Start Carousel Section -->
    <div class="home-slider">
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" style="padding-bottom: 30px;">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item active">
                    <img src="<?php echo e(asset('layouts/images/about-03.jpg')); ?>" class="img-responsive" alt="">
                </div>
                <div class="item">
                    <img src="<?php echo e(asset('layouts/images/about-02.jpg')); ?>" class="img-responsive" alt="">
                </div>
                <div class="item">
                    <img src="<?php echo e(asset('layouts/images/about-01.jpg')); ?>" class="img-responsive" alt="">
                </div>

            </div>

        </div>
    </div>
    <!-- Start Carousel Section -->

    <div class="row">
        <div class="col-md-6">
            <div class="menu-item color responsive">
                <a href="<?php echo url('category'); ?>" data-toggle="modal">
                    <i class="glyphicon glyphicon-th-list"></i>
                    <p><?php echo e(trans('money_lover.cate_all')); ?></p>
                </a>
            </div>
        </div>

        <div class="col-md-6">
            <div class="menu-item light-orange responsive-2">
                <a href="<?php echo url('addcategory'); ?>" data-toggle="modal">
                    <i class="fa fa-plus"></i>
                    <p><?php echo e(trans('money_lover.cate_new')); ?></p>
                </a>
            </div>
        </div>

    </div>

</div>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('transactions'); ?>" data-toggle="modal">
            <i class="fa fa-shopping-cart"></i>
            <p><?php echo e(trans('money_lover.trans_all')); ?></p>
        </a>
    </div>

    <div class="menu-item color">
        <a href="<?php echo url('addtransaction'); ?>" data-toggle="modal">
            <i class="fa fa-pencil-square-o"></i>
            <p><?php echo e(trans('money_lover.trans_new')); ?></p>
        </a>
    </div>

    <div class="menu-item blue">
        <a href="<?php echo url('reportmonth'); ?>" data-toggle="modal">
            <i class="fa fa-area-chart"></i>
            <p><?php echo e(trans('money_lover.trans_report')); ?></p>
        </a>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>