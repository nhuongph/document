<?php $__env->startSection('content'); ?>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('home'); ?>" data-toggle="modal">
            <i class="fa fa-home"></i>
            <p><?php echo e(trans('money_lover.wallet_home')); ?></p>
        </a>
    </div>

    <div class="menu-item blue">
        <a href="<?php echo url('addwallet'); ?>" data-toggle="modal">
            <i class="glyphicon glyphicon-star-empty"></i>
            <p><?php echo e(trans('money_lover.wallet_new')); ?></p>
        </a>
    </div>

</div>

<div class="col-md-9 bg-white padding-top-bot col-md-offset-0">
    <h1 class="text-center"><?php echo e(trans('money_lover.wallet')); ?></h1>
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php foreach($errors->all() as $error): ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo session('message'); ?></li>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(isset($current) && $current != ""): ?>
    <h2><?php echo e(trans('money_lover.wallet_current')); ?></h2>
    <div class="alert alert-info wallet">
        <table class="table table-striped">
            <tr>
                <th><?php echo e(trans('money_lover.wallet_avatar2')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_name')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_money')); ?>(<?php echo $current->type_money; ?>)</th>
                <th><?php echo e(trans('money_lover.wallet_note')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_action')); ?></th>
            </tr>
            <tr>
                <td><img src="<?php echo e($current->image); ?>" /></td>
                <td><?php echo $current->name; ?></td>
                <td><?php echo $current->money; ?></td>
                <td><?php echo $current->note; ?></td>
                <td>
                    <a href="<?php echo url('updatewallet'); ?>/<?php echo $current->id; ?>" title="Edit infor wallet">
                        <span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
                    </a>&nbsp;
                    <a href="<?php echo url('transwallet'); ?>/<?php echo $current->id; ?>" title="Transfer money to other wallet">
                        <span class="glyphicon glyphicon-transfer" aria-hidden="true"></span>
                    </a>&nbsp;
                    <a href="<?php echo url('deletewallet'); ?>/<?php echo $current->id; ?>" title="Delete wallet">
                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                    </a>
                </td>
            </tr>
        </table>                           
    </div>
    <?php endif; ?>

    <?php if(isset($wallets) && count($wallets) != 0): ?>
    <h2><?php echo e(trans('money_lover.wallet_other')); ?></h2>

    <div class="wallet">
        <table class="table table-striped">
            <tr>
                <th><?php echo e(trans('money_lover.wallet_avatar2')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_name')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_money')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_note')); ?></th>
                <th><?php echo e(trans('money_lover.wallet_action')); ?></th>
            </tr>
            <?php foreach($wallets as $var): ?>
            <tr>
                <td><img src="<?php echo $var->image; ?>" /></td>
                <td><?php echo $var->name; ?></td>
                <td><?php echo $var->money; ?>(<?php echo $var->type_money; ?>)</td>
                <td><?php echo $var->note; ?></td>
                <td>
                    <a href="<?php echo url('currentwallet'); ?>/<?php echo $var->id; ?>">
                        <span class="glyphicon glyphicon-ok" aria-hidden="true" title="Set current wallet"></span>
                    </a>&nbsp;<a href="<?php echo url('updatewallet'); ?>/<?php echo $var->id; ?>">
                        <span class="glyphicon glyphicon-edit" aria-hidden="true" title="Edit infor wallet"></span>
                    </a>&nbsp;
                    <a href="<?php echo url('transwallet'); ?>/<?php echo $var->id; ?>" title="Transfer money to other wallet">
                        <span class="glyphicon glyphicon-transfer" aria-hidden="true"></span>
                    </a>&nbsp;
                    <a href="<?php echo url('deletewallet'); ?>/<?php echo $var->id; ?>" title="Delete wallet">
                        <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>  

    </div>
    <?php endif; ?>
    <?php echo $wallets->links(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>