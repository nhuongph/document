<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Money lover</title>
        
        <!-- Bootstrap Core CSS -->
        <link href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">     
        <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- Font Awesome CSS -->
        <link href="<?php echo e(asset('layouts/css/font-awesome.min.css')); ?>" rel="stylesheet">
        
        <!-- Custom CSS -->
        <link href="<?php echo e(asset('layouts/css/animate.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('layouts/css/style.css')); ?>" rel="stylesheet">
        
        <!-- NhuongPH CSS -->
        <link href="<?php echo e(asset('layouts/css/mycss.css')); ?>" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href='<?php echo e(asset('layouts/css/font-Lobster.css')); ?>' rel='stylesheet' type='text/css'>

        <!-- Datepicker Fonts -->
        <link href='<?php echo e(asset('datepicker/css/datepicker.css')); ?>' rel='stylesheet' type='text/css'>

        <!-- Template js -->
        <script src="<?php echo e(asset('layouts/js/jquery-2.1.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/jquery.appear.js')); ?>"></script>
        <!--<script src="<?php echo e(asset('layouts/js/contact_me.js')); ?>"></script>-->
        <script src="<?php echo e(asset('layouts/js/jqBootstrapValidation.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/modernizr.custom.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/script.js')); ?>"></script>
        <script src="<?php echo e(asset('datepicker/js/bootstrap-datepicker.js')); ?>"></script>

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>
    
    <body>
        
        <!-- Start Logo Section -->
        <section id="logo-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="logo text-center">
                            <h1>Money Lover</h1>
                            <span><?php echo trans('money_lover.sologan'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="logo-right container">
                <?php if(Auth::check()){ ?>
                <?php echo e(trans('money_lover.welcome',['name' => Auth::user()->username])); ?> | <a href="<?php echo url('welcome/vi'); ?>">Việt Nam</a> &nbsp;<a href="<?php echo url('welcome/en'); ?>">English</a> | <a href="<?php echo url('logout'); ?>"><?php echo e(trans('money_lover.logout')); ?></a>
                <?php } ?>
            </div>
        </section>
        <!-- End Logo Section -->
        
        
        <!-- Start Main Body Section -->
        <div class="mainbody-section">
            <div class="container">
                <div class="row">                    
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <!-- End Main Body Section -->
        
    </body>
    
</html>