<?php $__env->startSection('content'); ?>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('login'); ?>" data-toggle="modal">
            <i class="fa fa-user"></i>
            <p><?php echo e(trans('money_lover.user_login')); ?></p>
        </a>
    </div>

    <div class="menu-item green">
        <a href="<?php echo url('register'); ?>" data-toggle="modal">
            <i class="fa fa fa-money"></i>
            <p><?php echo e(trans('money_lover.user_register')); ?></p>
        </a>
    </div>

    <div class="menu-item blue">
        <a href="<?php echo url('password/email'); ?>" data-toggle="modal">
            <i class="glyphicon glyphicon-star-empty"></i>
            <p><?php echo e(trans('money_lover.user_forgot')); ?></p>
        </a>
    </div>

</div>

<div class="col-md-8 bg-white padding-top-bot col-md-offset-1">
    <p class="text-center"><img id="profile-img" class="profile-img-card img-circle" src="<?php echo asset('images/avatar_2x.png'); ?>" />
    </p>
    <h1 class="text-center"><?php echo e(trans('money_lover.user_change_pass')); ?></h1>

    <div class="col-md-6 col-md-offset-3">
        <!-- Start Carousel Section -->
        <div class="card card-container">

            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(Session::has('message')): ?>

            <div class="alert alert-success">
                <ul>
                    <li><?php echo session('message'); ?></li>
                </ul>
            </div>
            <?php endif; ?>
            <?php echo Form::open(array('url' => '/password/reset','class'=>'form-signin')); ?>

            <?php echo Form::hidden('token',$token,null); ?>

            <div class="form-group">
                <?php echo Form::label('email',Lang::get('money_lover.user_email').':'); ?>

                <?php echo Form::email('email', null, ['class' => 'form-control','placeholder'=>Lang::get('money_lover.user_forgot_mes')]); ?>

            </div>
            <div class="form-group">                                    
                <?php echo Form::label('password',Lang::get('money_lover.user_pass').':'); ?>

                <?php echo Form::password('password', ['class' => 'form-control','placeholder'=>Lang::get('money_lover.user_pass')]); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('RE-password',Lang::get('money_lover.user_re_pass').':'); ?>

                <?php echo Form::password('password_confirmation', ['type'=>'password','class' => 'form-control','placeholder'=>Lang::get('money_lover.user_re_pass')]); ?>

            </div>
            <?php echo Form::submit(Lang::get('money_lover.user_change_pass'),['class' => 'btn btn-success']); ?>

            <?php echo Form::close(); ?><!-- /form -->
        </div><!-- /card-container -->
        <!-- Start Carousel Section -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>