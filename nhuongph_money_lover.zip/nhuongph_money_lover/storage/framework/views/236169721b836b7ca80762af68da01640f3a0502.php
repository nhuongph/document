<?php $__env->startSection('content'); ?>

<div class="col-md-3 text-center">

    <div class="menu-item light-red">
        <a href="<?php echo url('home'); ?>" data-toggle="modal">
            <i class="fa fa-home"></i>
            <p><?php echo e(trans('money_lover.home')); ?></p>
        </a>
    </div>

    <div class="menu-item light-red">
        <a href="<?php echo url('transactions'); ?>" data-toggle="modal">
            <i class="fa fa-shopping-cart"></i>
            <p><?php echo e(trans('money_lover.trans_all')); ?></p>
        </a>
    </div>

    <div class="menu-item color">
        <a href="<?php echo url('addtransaction'); ?>" data-toggle="modal">
            <i class="fa fa-pencil-square-o"></i>
            <p><?php echo e(trans('money_lover.trans_new')); ?></p>
        </a>
    </div>

</div>

<div class="col-md-9 bg-white padding-top-bot col-md-offset-0">
    <h1 class="text-center"><?php echo e(trans('money_lover.trans_report')); ?></h1>
    <div class="col-md-10 col-md-offset-1 padding-top-bot">
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <ul>
                <li><?php echo session('message'); ?></li>
            </ul>
        </div>
        <?php endif; ?>
        <?php echo Form::open(array('url' => 'reportmonth','class'=>'form-signin col-md-8')); ?>

        <div class="form-group">
            <?php echo Form::label('month',Lang::get('money_lover.trans_month').':'); ?>

            <?php echo Form::text('month',null, array('class'=>'datepicker form-control', 'data-date' => '102/2012' ,'data-date-format' => 'mm/yyyy', 'data-date-viewmode' => "years", 'data-date-minviewmode' =>"months",'placeholder'=>Lang::get('money_lover.trans_month'))); ?>

            <script>
                $('.datepicker').datepicker();
            </script>
        </div>
        <?php echo Form::submit(Lang::get('money_lover.trans_search'),['class' => 'btn btn-success']); ?>

        <?php echo Form::close(); ?>

        <div class="wallet padding-top-bot">
            <table class="table table-striped">
                <tr>
                    <th><?php echo e(trans('money_lover.avatar')); ?></th>
                    <th><?php echo e(trans('money_lover.trans_name')); ?></th>
                    <th><?php echo e(trans('money_lover.trans_money')); ?></th>
                    <th><?php echo e(trans('money_lover.note')); ?></th>
                    <th><?php echo e(trans('money_lover.action')); ?></th>
                </tr>
                <?php foreach($transmoneys as $var): ?>
                <tr>
                    <td><img src="<?php echo $var->image; ?>" /></td>
                    <td><?php echo $var->name; ?></td>
                    <td><?php echo $var->money; ?></td>
                    <td><?php echo $var->note; ?></td>
                    <td>
                        <a href="<?php echo url('updatetransaction'); ?>/<?php echo $var->id; ?>">
                            <span class="glyphicon glyphicon-edit" aria-hidden="true" title="<?php echo e(trans('money_lover.trans_update')); ?>"></span>
                        </a>&nbsp;
                        <a href="<?php echo url('deletetransaction'); ?>/<?php echo $var->id; ?>" title="<?php echo e(trans('money_lover.trans_del')); ?>">
                            <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>  
            <?php echo $transmoneys->links(); ?>

        </div>
        <div class="wallet padding-top-bot">
            <td><a class = "btn btn-success" href="<?php echo url('reportexcel'); ?>"><?php echo e(trans('money_lover.excel')); ?></a></td>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>