<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(CategoriesTableSeeder::class);
        //$this->call(TransactionMoneyTableSeeder::class);
        $this->call(WalletsTableSeeder::class);
<<<<<<< HEAD
        $this->call(UsersTableSeeder::class);
=======
>>>>>>> fea4ec9933c45c2ef1958abfb00ea0f8c160c0b8
    }
}
